﻿using System;

namespace StaticMethodAndClassExample
{
    class Program
    {
        static void Main(string[] args)
        {
            double addResult = Calculator.Add(12, 89);
            double multiplyResult = Calculator.Multiply(23.8, 6);
            Console.WriteLine(addResult);
            Console.WriteLine(multiplyResult);
        }
    }
}
