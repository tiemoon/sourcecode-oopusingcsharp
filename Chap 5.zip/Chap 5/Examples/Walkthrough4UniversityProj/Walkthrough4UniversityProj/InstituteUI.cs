﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Walkthrough4UniversityProj
{
    public partial class InstituteUI : Form
    {
        Department anInstitute;
        string outputFormat = "{0,-20}\t{1,-20}\t{2,-20}\t{3,-20}";
        public InstituteUI()
        {
            InitializeComponent();
            studentEnrollComboBox.DisplayMember = "RegNo";
            studentReportComboBox.DisplayMember = "RegNo";
            courseEntollComboBox.DisplayMember = "Title";
            
            anInstitute = new Department();
            
        }

        private void addCourseButton_Click(object sender, EventArgs e)
        {
            Course aCourse = new Course();
            aCourse.Title = courseTitleTextBox.Text;
            if (level1RadioButton.Checked)
            {
                aCourse.Level = level1RadioButton.Text;
            }
            
            if (level2RadioButton.Checked)
            {
                aCourse.Level = level2RadioButton.Text;
            }

            if (level3RadioButton.Checked)
            {
                aCourse.Level = level3RadioButton.Text;
            }
            aCourse.DurationInHour = Convert.ToInt16(courseDurationTextBox.Text);
            anInstitute.Courses.Add(aCourse);
            courseEntollComboBox.Items.Add(aCourse);
            MessageBox.Show("Course info has been added.");
        }

        private void addStudentButton_Click(object sender, EventArgs e)
        {
            Student aStudent = new Student();
            aStudent.Name = studentNameTextBox.Text;
            aStudent.ContactNo = studentContactNoTextBox.Text;
            aStudent.Email = studentEmailTextBox.Text;
            aStudent.RegNo = studentRegNoTextBox.Text;
            anInstitute.Students.Add(aStudent);
            studentEnrollComboBox.Items.Add(aStudent);
            studentReportComboBox.Items.Add(aStudent);
            MessageBox.Show("Student info has been saved.");
        }

        private void enrollButton_Click(object sender, EventArgs e)
        {
            Enrollment anEnrollment = new Enrollment();
            anEnrollment.Student = (Student)studentEnrollComboBox.SelectedItem;
            anEnrollment.Course = (Course)courseEntollComboBox.SelectedItem;
            anEnrollment.EnrollmentDate = enrollmentDateDateTimePicker.Value;
            anInstitute.Enrollments.Add(anEnrollment);
            MessageBox.Show("Enrollment info has been saved.");
        }

        private void showEnrolledCoursesButton_Click(object sender, EventArgs e)
        {
            enrolledCoursesListBox.Items.Clear();
            enrolledCoursesListBox.Items.Add(string.Format(outputFormat, "Title", "Level", "Duration (in Hr)", "Enrollment Date"));
            Student selectedStudent = (Student)studentReportComboBox.SelectedItem;
            foreach (Enrollment enrollment in anInstitute.Enrollments)
            {
                if (selectedStudent.RegNo == enrollment.Student.RegNo)
                {
                    enrolledCoursesListBox.Items.Add(string.Format(outputFormat, enrollment.Course.Title, enrollment.Course.Level, enrollment.Course.DurationInHour, enrollment.EnrollmentDate));
                }
            }
        }
    }
}

