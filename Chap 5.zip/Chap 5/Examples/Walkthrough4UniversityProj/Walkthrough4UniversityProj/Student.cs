﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Walkthrough4UniversityProj
{
    public class Student
    {
        public string Name { set; get; }
        public string ContactNo { set; get; }
        public string Email { set; get; }
        public string RegNo { set; get; }
    }
}
