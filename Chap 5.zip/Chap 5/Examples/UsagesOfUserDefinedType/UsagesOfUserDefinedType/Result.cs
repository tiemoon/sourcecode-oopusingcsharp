﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UsagesOfUserDefinedType
{
    class Result
    {
    }
}
