﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UsagesOfUserDefinedType
{
    class Student
    {
        public Student()
        {
        }

        public Result ResultSheet { set; get; }
        public Student(string name, string email)
        {
            Name = name;
            Email = email;
        }
        public string Name { set; get; }
        public string Email { set; get; }
        public string RegNo { set; get; }
    }
}
