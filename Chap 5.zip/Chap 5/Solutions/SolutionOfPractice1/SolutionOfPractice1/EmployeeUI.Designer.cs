﻿namespace SolutionOfPractice1
{
    partial class EmployeeUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.emailEntryTextBox = new System.Windows.Forms.TextBox();
            this.nameEntryTextBox = new System.Windows.Forms.TextBox();
            this.idEntryTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.convEntryTextBox = new System.Windows.Forms.TextBox();
            this.medicalPercentEntryTextBox = new System.Windows.Forms.TextBox();
            this.basicEntryTextBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.totalShowTextBox = new System.Windows.Forms.TextBox();
            this.convAmountShowTextBox = new System.Windows.Forms.TextBox();
            this.medicalAmountShowTextBox = new System.Windows.Forms.TextBox();
            this.basicShowTextBox = new System.Windows.Forms.TextBox();
            this.emailShowTextBox = new System.Windows.Forms.TextBox();
            this.nameShowTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.idShowTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // showButton
            // 
            this.showButton.Location = new System.Drawing.Point(204, 24);
            this.showButton.Name = "showButton";
            this.showButton.Size = new System.Drawing.Size(75, 23);
            this.showButton.TabIndex = 2;
            this.showButton.Text = "Show";
            this.showButton.UseVisualStyleBackColor = true;
            this.showButton.Click += new System.EventHandler(this.showButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(164, 229);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(75, 23);
            this.saveButton.TabIndex = 12;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // emailEntryTextBox
            // 
            this.emailEntryTextBox.Location = new System.Drawing.Point(77, 89);
            this.emailEntryTextBox.Name = "emailEntryTextBox";
            this.emailEntryTextBox.Size = new System.Drawing.Size(162, 20);
            this.emailEntryTextBox.TabIndex = 8;
            // 
            // nameEntryTextBox
            // 
            this.nameEntryTextBox.Location = new System.Drawing.Point(77, 64);
            this.nameEntryTextBox.Name = "nameEntryTextBox";
            this.nameEntryTextBox.Size = new System.Drawing.Size(162, 20);
            this.nameEntryTextBox.TabIndex = 7;
            // 
            // idEntryTextBox
            // 
            this.idEntryTextBox.Location = new System.Drawing.Point(77, 39);
            this.idEntryTextBox.Name = "idEntryTextBox";
            this.idEntryTextBox.Size = new System.Drawing.Size(162, 20);
            this.idEntryTextBox.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Id";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.saveButton);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.emailEntryTextBox);
            this.groupBox1.Controls.Add(this.nameEntryTextBox);
            this.groupBox1.Controls.Add(this.convEntryTextBox);
            this.groupBox1.Controls.Add(this.idEntryTextBox);
            this.groupBox1.Controls.Add(this.medicalPercentEntryTextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.basicEntryTextBox);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 269);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(242, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "% of Basic";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(242, 206);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "% of Basic";
            // 
            // convEntryTextBox
            // 
            this.convEntryTextBox.Location = new System.Drawing.Point(77, 203);
            this.convEntryTextBox.Name = "convEntryTextBox";
            this.convEntryTextBox.Size = new System.Drawing.Size(162, 20);
            this.convEntryTextBox.TabIndex = 11;
            this.convEntryTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // medicalPercentEntryTextBox
            // 
            this.medicalPercentEntryTextBox.Location = new System.Drawing.Point(77, 176);
            this.medicalPercentEntryTextBox.Name = "medicalPercentEntryTextBox";
            this.medicalPercentEntryTextBox.Size = new System.Drawing.Size(162, 20);
            this.medicalPercentEntryTextBox.TabIndex = 10;
            this.medicalPercentEntryTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // basicEntryTextBox
            // 
            this.basicEntryTextBox.Location = new System.Drawing.Point(77, 150);
            this.basicEntryTextBox.Name = "basicEntryTextBox";
            this.basicEntryTextBox.Size = new System.Drawing.Size(162, 20);
            this.basicEntryTextBox.TabIndex = 9;
            this.basicEntryTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 207);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Conveyance";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(26, 182);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Medical";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(74, 127);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Salary Information";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(74, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Employee Information";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(37, 155);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "Basic";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.showButton);
            this.groupBox4.Controls.Add(this.totalShowTextBox);
            this.groupBox4.Controls.Add(this.convAmountShowTextBox);
            this.groupBox4.Controls.Add(this.medicalAmountShowTextBox);
            this.groupBox4.Controls.Add(this.basicShowTextBox);
            this.groupBox4.Controls.Add(this.emailShowTextBox);
            this.groupBox4.Controls.Add(this.nameShowTextBox);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.idShowTextBox);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Location = new System.Drawing.Point(325, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(294, 269);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Show All Info";
            // 
            // totalShowTextBox
            // 
            this.totalShowTextBox.Location = new System.Drawing.Point(118, 208);
            this.totalShowTextBox.Name = "totalShowTextBox";
            this.totalShowTextBox.Size = new System.Drawing.Size(161, 20);
            this.totalShowTextBox.TabIndex = 11;
            this.totalShowTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // convAmountShowTextBox
            // 
            this.convAmountShowTextBox.Location = new System.Drawing.Point(118, 181);
            this.convAmountShowTextBox.Name = "convAmountShowTextBox";
            this.convAmountShowTextBox.Size = new System.Drawing.Size(161, 20);
            this.convAmountShowTextBox.TabIndex = 11;
            this.convAmountShowTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // medicalAmountShowTextBox
            // 
            this.medicalAmountShowTextBox.Location = new System.Drawing.Point(118, 155);
            this.medicalAmountShowTextBox.Name = "medicalAmountShowTextBox";
            this.medicalAmountShowTextBox.Size = new System.Drawing.Size(161, 20);
            this.medicalAmountShowTextBox.TabIndex = 10;
            this.medicalAmountShowTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // basicShowTextBox
            // 
            this.basicShowTextBox.Location = new System.Drawing.Point(118, 131);
            this.basicShowTextBox.Name = "basicShowTextBox";
            this.basicShowTextBox.Size = new System.Drawing.Size(161, 20);
            this.basicShowTextBox.TabIndex = 9;
            this.basicShowTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // emailShowTextBox
            // 
            this.emailShowTextBox.Location = new System.Drawing.Point(118, 105);
            this.emailShowTextBox.Name = "emailShowTextBox";
            this.emailShowTextBox.Size = new System.Drawing.Size(161, 20);
            this.emailShowTextBox.TabIndex = 8;
            // 
            // nameShowTextBox
            // 
            this.nameShowTextBox.Location = new System.Drawing.Point(118, 78);
            this.nameShowTextBox.Name = "nameShowTextBox";
            this.nameShowTextBox.Size = new System.Drawing.Size(161, 20);
            this.nameShowTextBox.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(82, 212);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Total";
            // 
            // idShowTextBox
            // 
            this.idShowTextBox.Location = new System.Drawing.Point(118, 53);
            this.idShowTextBox.Name = "idShowTextBox";
            this.idShowTextBox.Size = new System.Drawing.Size(161, 20);
            this.idShowTextBox.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Conveyance Amount";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Medical Amount";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(80, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Basic";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(81, 108);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 13);
            this.label19.TabIndex = 2;
            this.label19.Text = "Email";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(78, 82);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 13);
            this.label20.TabIndex = 1;
            this.label20.Text = "Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(97, 58);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "Id";
            // 
            // EmployeeUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 300);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Name = "EmployeeUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button showButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.TextBox emailEntryTextBox;
        private System.Windows.Forms.TextBox nameEntryTextBox;
        private System.Windows.Forms.TextBox idEntryTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox convEntryTextBox;
        private System.Windows.Forms.TextBox medicalPercentEntryTextBox;
        private System.Windows.Forms.TextBox basicEntryTextBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox convAmountShowTextBox;
        private System.Windows.Forms.TextBox medicalAmountShowTextBox;
        private System.Windows.Forms.TextBox basicShowTextBox;
        private System.Windows.Forms.TextBox emailShowTextBox;
        private System.Windows.Forms.TextBox nameShowTextBox;
        private System.Windows.Forms.TextBox idShowTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox totalShowTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
    }
}

