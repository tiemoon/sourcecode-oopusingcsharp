﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walkthrough4MethodOverriding
{
    class Regular : Participant
    {
        public string AlternativeContactNo { set; get; }
    }
}
