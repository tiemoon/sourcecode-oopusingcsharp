﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walkthrough5RuntimePolymorphism
{
    public class Course
    {
        public string Name { set; get; }
        public double Fee { set; get; }
        public int Level { set; get; }
        public double ExtraFeeForPickHour { set; get; }
    }
}
