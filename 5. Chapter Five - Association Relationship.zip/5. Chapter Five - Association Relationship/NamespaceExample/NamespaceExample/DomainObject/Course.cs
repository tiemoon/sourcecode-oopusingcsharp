﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NamespaceExample.DomainObject
{
    public class Course
    {
        public string Title { set; get; }
        public string Level { set; get; }
        public int DurationInHour { set; get; }
    }
}
