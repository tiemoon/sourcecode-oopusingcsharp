﻿namespace UniversityManagementSystem
{
    class Department
    {
    }
}
