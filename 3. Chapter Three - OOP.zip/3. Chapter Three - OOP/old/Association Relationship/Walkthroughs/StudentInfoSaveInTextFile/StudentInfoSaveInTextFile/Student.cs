﻿namespace StudentInfoSaveInTextFile
{
    class Student
    {
        public string FirstName { set; get; }
        public string LastName { set; get; }
        public string RegNo { set; get; }
        public ContactInfo ContactInfo { set; get; }
    }
}
