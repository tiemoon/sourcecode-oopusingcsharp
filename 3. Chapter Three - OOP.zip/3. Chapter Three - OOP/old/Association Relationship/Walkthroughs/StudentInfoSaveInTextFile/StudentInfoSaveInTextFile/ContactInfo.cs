﻿namespace StudentInfoSaveInTextFile
{
    class ContactInfo
    {
        public string MobileNo { set; get; }
        public string Email { set; get; }
        public string PostalAddress { set; get; }
    }
}
