﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentInfoWindowsForm
{
    class ContactInfo
    {
        public string MobileNo { set; get; }
        public string Email { set; get; }
        public string PostalAddress { set; get; }
    }
}
