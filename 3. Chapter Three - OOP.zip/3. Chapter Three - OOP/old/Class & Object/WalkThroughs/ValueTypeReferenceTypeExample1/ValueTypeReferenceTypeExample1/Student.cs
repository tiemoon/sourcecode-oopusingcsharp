namespace ValueTypeReferenceTypeExample1
{
    public class Student
    {
        public string Name { set; get; }
        public double CGPA { set; get; }
        public int AgeInYear { set; get; }

    }
}