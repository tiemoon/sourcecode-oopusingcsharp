﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChangeMakerExample2
{
    public class Student
    {
        public string name;
        public double cGPA;
        public int ageInYear;
    }
}
