﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentExample
{
    public class Student
    {
        public string name;
        public double cGPA;
        public int ageInYear;
    }
}
