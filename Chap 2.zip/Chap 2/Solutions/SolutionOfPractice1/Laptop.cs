﻿namespace SolutionOfPractice1
{
    class Laptop
    {
        public string brandName;
        public int ramSizeInGB;
        public int NumberOfCore;
    }
}
