﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticMethodAndClassExample
{
    class Program
    {
        static void Main(string[] args)
        {
            double addResult = Calculator.Add(12, 89);
            double multiplyResult = Calculator.Multiply(23.8, 6);
            Console.WriteLine(addResult);
            Console.WriteLine(multiplyResult);
            Console.ReadKey();
        }
    }
}
