﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Text;

namespace UniversityManagement3
{
    class Teacher: IBasicInformation, ISaveInFile
    {
        public string TeacherCode { set; get; }
        public String Name { set; get; }
        public string EducationalQualification { set; get; }
        public string Email { set; get; }
        public string ContactNo { set; get; }
        public string Specialization { set; get; }

        public string GetBasicInfo()
        {
            return "Name: " + Name + " " +
                    "Email: " + Email + " " +
                    "Contact No:" + ContactNo;
        }

        public void SaveData(string location)
        {
            using (StreamWriter sw = File.AppendText(location))
            {
                sw.WriteLine(@"Teacher::  Code: " + TeacherCode 
                    + " Name: " + Name + " Contact: " 
                    + ContactNo);
            }
        }
    }
}
