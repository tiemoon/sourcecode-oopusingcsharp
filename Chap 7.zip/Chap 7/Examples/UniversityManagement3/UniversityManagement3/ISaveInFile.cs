﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniversityManagement3
{
    interface ISaveInFile
    {
        void SaveData(string location);
    }
}
