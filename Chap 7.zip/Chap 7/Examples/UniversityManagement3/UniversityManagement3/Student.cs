﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text;

namespace UniversityManagement3
{
    class Student : IBasicInformation, ISaveInFile
    {
        public string RegNo { set; get; }
        public string Name { set; get; }
        public string Email { set; get; }
        public string Address { set; get; }



        public string GetBasicInfo()
        {
            return "Name: " + Name + " " +
                   "EMail: " + Email + " " +
                   "Address: " + Address;
        }

        public void SaveData(string location)
        {
            using (StreamWriter sw = File.AppendText(location))
            {
                sw.WriteLine(@"Student::  RegNo: " + RegNo + " Name: " + Name + " Email: " + Email);
            }
        }
    }
}
