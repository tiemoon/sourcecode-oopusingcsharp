﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace UniversityManagement3
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student();
            student1.RegNo = "675-928";
            student1.Name = "Jamil";
            student1.Email = "j@mail.com";


            Student student2 = new Student();
            student2.RegNo = "987-098";
            student2.Name = "Shimi";
            student2.Email = "s@mail.com";

            Course course1 = new Course();
            course1.CodeName = "CSE-101";
            course1.Title = "Computer Science Basics";
            course1.Credit = 3.0;

            Course course2 = new Course();
            course2.CodeName = "CSE-304";
            course2.Title = "Networking";
            course2.Credit = 4.0;

            Teacher teacher1 = new Teacher();
            teacher1.Name = "Asifur Rahman";
            teacher1.Email = "ar@mail.com";
            teacher1.ContactNo = "7638-8363";

            Teacher teacher2 = new Teacher();
            teacher2.Name = "Polash Chaw.";
            teacher2.Email = "pc@mail.com";
            teacher2.ContactNo = "0912928";

            List<IBasicInformation> basicInfoList = new List<IBasicInformation>()
            {student1, student2, course1, course2, teacher1,teacher2};

            foreach (IBasicInformation info in basicInfoList)
            {
                info.


            }





            List<ISaveInFile> saveInFileList = new List<ISaveInFile>
            { teacher1, teacher2, student1, student2 };

            foreach (ISaveInFile anObject in saveInFileList)
            {
                anObject.
            }
        }
    }
}
