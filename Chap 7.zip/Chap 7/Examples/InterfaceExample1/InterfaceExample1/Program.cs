﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample1
{
    class Program
    {
        static void Main(string[] args)
        {
            SavingsAccount savings1 = new SavingsAccount();
            RegularAccount regular1 = new RegularAccount();
            savings1.Deposit(3000);
            savings1.Withdraw(1500);

            List<IBankAccount> bankAccountList = new List<IBankAccount>();
            bankAccountList.Add(savings1);
            bankAccountList.Add(regular1);

            foreach (IBankAccount anAccount in bankAccountList)
            {
                anAccount.Deposit(2000);
            }

            foreach (IBankAccount anAccount in bankAccountList)
            {
                Console.WriteLine(anAccount.Balance);
            }
            Console.ReadKey();
        }
    }
}
