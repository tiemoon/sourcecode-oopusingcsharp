﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample1
{
    class RegularAccount : IBankAccount
    {
        public string ServiceCharge { set; get; }
        public string AccountNo { get; set; }
        public double Balance { private set; get; }

        public void Deposit(double amount)
        {
            Balance += amount;
        }

        public void Withdraw(double amount)
        {
            if ((Balance - amount) >= 100)
            {
                Balance -= amount;
            }
            else
            {
                throw new Exception("Insufficient balance");
            }
        }
    }
}
