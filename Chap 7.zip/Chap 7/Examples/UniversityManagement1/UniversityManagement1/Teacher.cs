﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniversityManagement1
{
    class Teacher
    {
        public string TeacherCode { set; get; }
        public String Name { set; get; }
        public string EducationalQualification { set; get; }
        public string Email { set; get; }
        public string ContactNo { set; get; }
        public string Specialization { set; get; }

        public List<string> TeacherDetails()
        {
            List<string> dtl = new List<string>();
            dtl.Add(Name);
            dtl.Add(Email);
            dtl.Add(ContactNo);
            return dtl;
        }

    }

}
