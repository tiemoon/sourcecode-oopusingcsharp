﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniversityManagement1
{
    class Course
    {
        public string CodeName { set; get; }
        public string Title { set; get; }
        public string Description { set; get; }
        public double Credit { set; get; }

        public string SomeData()
        {
            return "Name: " + CodeName + " " +
                   "Title: " + Title + " " +
                   "Credit: " + Credit;
        }

    }

}
