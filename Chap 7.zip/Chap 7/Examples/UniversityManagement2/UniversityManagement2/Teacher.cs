﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniversityManagement2
{
    class Teacher : IBasicInformation
    {
        public string TeacherCode { set; get; }
        public String Name { set; get; }
        public string EducationalQualification { set; get; }
        public string Email { set; get; }
        public string ContactNo { set; get; }
        public string Specialization { set; get; }
        public string GetBasicInfo()
        {
            return "Name: " + Name + " " +
                   "Email: " + Email + " " +
                   "Contact No:" + ContactNo;
        }
    }
}
