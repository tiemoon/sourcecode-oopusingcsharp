﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniversityManagement2
{
    interface IBasicInformation
    {
        string GetBasicInfo();
    }

}
