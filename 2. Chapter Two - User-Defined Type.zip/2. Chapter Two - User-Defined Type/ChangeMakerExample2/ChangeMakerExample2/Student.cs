﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChangeMakerExample2
{
    public class Student
    {
        public string name;
        public double cGPA;
        public int ageInYear;

    }
}
