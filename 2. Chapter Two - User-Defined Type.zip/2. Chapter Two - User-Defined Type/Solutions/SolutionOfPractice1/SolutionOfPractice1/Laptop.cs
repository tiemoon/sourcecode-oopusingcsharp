﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolutionOfPractice1
{
    class Laptop
    {
        public string brandName;
        public int ramSizeInGB;
        public int NumberOfCore;
    }
}
