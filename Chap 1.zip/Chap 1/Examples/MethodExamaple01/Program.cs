﻿using System;

namespace MethodExamaple01
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintSomething();
        }

        static void PrintSomething()
        {
            string aText = "Hi, I am Polin and he is Rumi";
            Console.WriteLine(aText);
        }
    }
}
