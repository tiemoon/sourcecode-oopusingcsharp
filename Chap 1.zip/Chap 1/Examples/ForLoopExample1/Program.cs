﻿using System;

namespace ForLoopExample1
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 1000; i++)
            {
                Console.WriteLine("OOP concept is very essential");
            }
        }
    }
}
