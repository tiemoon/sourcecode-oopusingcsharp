﻿using System;

namespace VariableExampleBoolType
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isValid = true;
            bool isRaining = false;
            Console.WriteLine(isValid);
            Console.WriteLine(isRaining);
        }
    }
}
