﻿using System;

namespace MethodExample02
{
    class Program
    {
        static void Main(string[] args)
        {
            ShowName("Rabbi");
            string name = "Jamil";
            ShowName(name);
        }

        static void ShowName(string aName)
        {
            Console.WriteLine(aName);
        }
    }
}
