﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walkthrough3UpcastingDownCasting
{
    class Professional : Participant
    {
        public string CompanyName { set; get; }
        public string CompanyContact { set; get; }
    }
}
