﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walkthrough3UpcastingDownCasting
{
    public class Course
    {
        public string Name { set; get; }
        public double Fee { set; get; }
        public int Level { set; get; }
    }
}
