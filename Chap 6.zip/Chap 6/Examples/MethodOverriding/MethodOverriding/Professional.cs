﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverriding
{
    class Professional : Participant
    {
        public string CompanyName { set; get; }
        public string CompanyContact { set; get; }
        public override double GetTotalPayable()
        {
            double total = base.GetTotalPayable();
            double extraAmount = total * 0.1;
            return (total + extraAmount);
        }
    }
}
