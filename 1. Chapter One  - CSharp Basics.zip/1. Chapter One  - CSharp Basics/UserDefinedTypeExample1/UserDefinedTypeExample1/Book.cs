﻿namespace UserDefinedTypeExample1
{
    public class Book
    {
        public string title;
        public string author;
        public double price;
    }
}