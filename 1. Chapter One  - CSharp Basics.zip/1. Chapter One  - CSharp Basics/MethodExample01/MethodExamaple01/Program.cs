﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodExamaple01
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintSomething();
            Console.ReadLine();
        }

        static void PrintSomething()
        {
            string aText = "Hi, I am Polin and he is Rumi";
            Console.WriteLine(aText);
        }
    }

}
