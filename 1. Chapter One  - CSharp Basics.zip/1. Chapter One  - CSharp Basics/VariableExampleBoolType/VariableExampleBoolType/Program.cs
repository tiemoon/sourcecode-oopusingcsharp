﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariableExampleBoolType
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isValid = true;
            bool isRaining = false;
            Console.WriteLine(isValid);
            Console.WriteLine(isRaining);
            Console.ReadKey();
        }
    }
}
